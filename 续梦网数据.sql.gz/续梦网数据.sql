-- MySQL dump 10.13  Distrib 5.6.50, for Linux (x86_64)
--
-- Host: localhost    Database: wap
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_obmen` int(11) NOT NULL,
  `text` varchar(9999) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_msg`
--

DROP TABLE IF EXISTS `forum_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_msg` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `id_theme` int(11) NOT NULL,
  `text` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_msg`
--

LOCK TABLES `forum_msg` WRITE;
/*!40000 ALTER TABLE `forum_msg` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_podrazdel`
--

DROP TABLE IF EXISTS `forum_podrazdel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_podrazdel` (
  `id` int(11) NOT NULL,
  `id_razdel` int(11) NOT NULL,
  `name` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_podrazdel`
--

LOCK TABLES `forum_podrazdel` WRITE;
/*!40000 ALTER TABLE `forum_podrazdel` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_podrazdel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_razdel`
--

DROP TABLE IF EXISTS `forum_razdel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_razdel` (
  `id` int(11) NOT NULL,
  `name` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_razdel`
--

LOCK TABLES `forum_razdel` WRITE;
/*!40000 ALTER TABLE `forum_razdel` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_razdel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forum_theme`
--

DROP TABLE IF EXISTS `forum_theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forum_theme` (
  `id` int(11) NOT NULL,
  `id_podraz` int(11) NOT NULL,
  `up` int(11) NOT NULL,
  `name` varchar(1000) NOT NULL,
  `id_user` int(11) NOT NULL,
  `text` varchar(9000) NOT NULL,
  `time` int(11) NOT NULL,
  `status` enum('open','closed') NOT NULL DEFAULT 'open',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forum_theme`
--

LOCK TABLES `forum_theme` WRITE;
/*!40000 ALTER TABLE `forum_theme` DISABLE KEYS */;
/*!40000 ALTER TABLE `forum_theme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game`
--

DROP TABLE IF EXISTS `game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_game` int(11) NOT NULL,
  `id_user` int(11) NOT NULL COMMENT '用户uid',
  `icon` varchar(9999) NOT NULL COMMENT '图标',
  `name` varchar(1000) NOT NULL COMMENT '名称',
  `cn` varchar(50) DEFAULT NULL COMMENT '中文名',
  `author` varchar(100) NOT NULL COMMENT '厂商',
  `raz` varchar(250) NOT NULL COMMENT '分类',
  `platform` varchar(250) NOT NULL COMMENT '平台',
  `zh` varchar(5) NOT NULL COMMENT '语言',
  `size` int(250) NOT NULL COMMENT '大小字节',
  `v` varchar(8) DEFAULT NULL COMMENT '版本',
  `downs` int(11) NOT NULL DEFAULT '0' COMMENT '下载量',
  `dpi` varchar(10) NOT NULL COMMENT '分辨率',
  `DJ` varchar(5) NOT NULL COMMENT '单机联机',
  `img` varchar(2) DEFAULT '没图' COMMENT '截图获取',
  `text` varchar(1000) DEFAULT NULL COMMENT '介绍',
  `down` varchar(250) NOT NULL COMMENT '下载链接',
  `time` int(11) NOT NULL COMMENT '上传时间',
  `format` varchar(250) NOT NULL COMMENT '后缀名',
  `ivent` varchar(3) DEFAULT '通过',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game`
--

LOCK TABLES `game` WRITE;
/*!40000 ALTER TABLE `game` DISABLE KEYS */;
/*!40000 ALTER TABLE `game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_download`
--

DROP TABLE IF EXISTS `game_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_download` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `downs` int(11) DEFAULT NULL,
  `game_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_download`
--

LOCK TABLES `game_download` WRITE;
/*!40000 ALTER TABLE `game_download` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_download` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(9999) NOT NULL,
  `format` varchar(5) NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `id_game` int(11) NOT NULL,
  `background` int(11) DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `komm_news`
--

DROP TABLE IF EXISTS `komm_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `komm_news` (
  `id` int(11) NOT NULL,
  `id_news` int(11) NOT NULL,
  `id_author` int(11) NOT NULL,
  `text` varchar(9999) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `komm_news`
--

LOCK TABLES `komm_news` WRITE;
/*!40000 ALTER TABLE `komm_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `komm_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_auth`
--

DROP TABLE IF EXISTS `log_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_auth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(250) NOT NULL,
  `type` enum('0','1') NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_auth`
--

LOCK TABLES `log_auth` WRITE;
/*!40000 ALTER TABLE `log_auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `msg`
--

DROP TABLE IF EXISTS `msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `msg` (
  `id` int(11) NOT NULL,
  `text` varchar(9500) NOT NULL,
  `time` int(11) NOT NULL,
  `read` enum('0','1') NOT NULL DEFAULT '0',
  `id_user` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `msg`
--

LOCK TABLES `msg` WRITE;
/*!40000 ALTER TABLE `msg` DISABLE KEYS */;
/*!40000 ALTER TABLE `msg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `msg_chat`
--

DROP TABLE IF EXISTS `msg_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `msg_chat` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_room` int(11) NOT NULL,
  `text` varchar(2500) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `msg_chat`
--

LOCK TABLES `msg_chat` WRITE;
/*!40000 ALTER TABLE `msg_chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `msg_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `text` varchar(9999) NOT NULL,
  `author` int(11) NOT NULL,
  `time_new` int(11) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_chat`
--

DROP TABLE IF EXISTS `room_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `room_chat` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `info` varchar(400) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_chat`
--

LOCK TABLES `room_chat` WRITE;
/*!40000 ALTER TABLE `room_chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `room_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_log`
--

DROP TABLE IF EXISTS `search_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `search_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(250) NOT NULL,
  `num` int(11) NOT NULL,
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_log`
--

LOCK TABLES `search_log` WRITE;
/*!40000 ALTER TABLE `search_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `reg_on` enum('0','1') NOT NULL DEFAULT '1',
  `aut_ban_time` int(11) NOT NULL DEFAULT '60',
  `index_forum` int(11) NOT NULL DEFAULT '5',
  `uphold` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'0',600,7,0);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theme`
--

DROP TABLE IF EXISTS `theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `theme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_raz` varchar(250) NOT NULL,
  `id_user` varchar(250) NOT NULL,
  `icon` varchar(9999) NOT NULL,
  `downs` int(11) NOT NULL DEFAULT '0',
  `name` varchar(1000) DEFAULT NULL,
  `platform` varchar(250) NOT NULL,
  `text` varchar(250) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme`
--

LOCK TABLES `theme` WRITE;
/*!40000 ALTER TABLE `theme` DISABLE KEYS */;
/*!40000 ALTER TABLE `theme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theme_comment`
--

DROP TABLE IF EXISTS `theme_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `theme_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_obmen` int(11) NOT NULL,
  `text` varchar(9999) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme_comment`
--

LOCK TABLES `theme_comment` WRITE;
/*!40000 ALTER TABLE `theme_comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `theme_comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theme_download`
--

DROP TABLE IF EXISTS `theme_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `theme_download` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `downs` int(11) DEFAULT NULL,
  `theme_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme_download`
--

LOCK TABLES `theme_download` WRITE;
/*!40000 ALTER TABLE `theme_download` DISABLE KEYS */;
/*!40000 ALTER TABLE `theme_download` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theme_image`
--

DROP TABLE IF EXISTS `theme_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `theme_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(9999) NOT NULL,
  `format` varchar(5) NOT NULL,
  `id_user` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `id_theme` int(11) NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme_image`
--

LOCK TABLES `theme_image` WRITE;
/*!40000 ALTER TABLE `theme_image` DISABLE KEYS */;
/*!40000 ALTER TABLE `theme_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theme_search_log`
--

DROP TABLE IF EXISTS `theme_search_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `theme_search_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(250) NOT NULL,
  `num` int(11) NOT NULL,
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme_search_log`
--

LOCK TABLES `theme_search_log` WRITE;
/*!40000 ALTER TABLE `theme_search_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `theme_search_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qq` varchar(250) DEFAULT NULL,
  `baidu` varchar(250) DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  `theme_downs` int(11) DEFAULT '0',
  `downs` int(11) DEFAULT '0',
  `v_name` varchar(8) DEFAULT NULL,
  `v` int(11) DEFAULT NULL,
  `qq_avatar` varchar(250) DEFAULT NULL,
  `baidu_avatar` varchar(250) DEFAULT NULL,
  `login` varchar(50) NOT NULL,
  `pass` varchar(80) NOT NULL,
  `pol` varchar(2) NOT NULL DEFAULT '未知',
  `data_reg` int(11) NOT NULL DEFAULT '1',
  `admin_level` varchar(3) NOT NULL DEFAULT '会员',
  `ip` varchar(250) NOT NULL,
  `up_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'wap'
--

--
-- Dumping routines for database 'wap'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-12-09 22:56:59
