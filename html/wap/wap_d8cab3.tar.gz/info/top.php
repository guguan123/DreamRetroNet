<?php
echo '<div id="aside">
<ul class="list icon line bg-white">
<li><a href="/info/1">免责声明</a></li>
<li><a href="/info/2">联系我们</a></li>
<li><a href="/info/3">捐助网站</a></li>
<li><a href="/info/4">常见问题</a></li>
</ul></div></div>';
?>
