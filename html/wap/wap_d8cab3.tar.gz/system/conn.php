
<?php
$dbhost = "localhost";
$dbname = "wap";
$dbuser = "wap";
$dbpass = "hf5ZPCzNnfbH6fpb";
?>