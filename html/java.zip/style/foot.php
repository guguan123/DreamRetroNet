<?php

$end_time = microtime();

$end_array = explode(" ", $end_time);

$end_time = $end_array[1] + $end_array[0];

$time = $end_time - $start_time;
echo '</div>
</div>
</div>
</div>
<div class="bottom">
    <div id="body">java游戏<a href="/">乐园</a> 2019</div>
</div>';
?>

