<?php
include_once $_SERVER["DOCUMENT_ROOT"].'/system/base.php';
$title = 'Выход';
include_once $_SERVER["DOCUMENT_ROOT"].'/style/head.php';
aut();

setcookie('login','', time()-86400*365, '/'); 
setcookie('pass','', time()-86400*365, '/');
header('Location: /');
include_once $_SERVER["DOCUMENT_ROOT"].'/style/foot.php';
?>