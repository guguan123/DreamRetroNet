<?php
include_once $_SERVER["DOCUMENT_ROOT"].'/system/base.php';
$title = '用户';
include_once $_SERVER["DOCUMENT_ROOT"].'/style/head.php';

aut();

echo '功能开发中';


include_once $_SERVER["DOCUMENT_ROOT"].'/style/foot.php';
?>