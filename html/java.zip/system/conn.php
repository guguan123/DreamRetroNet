
<?php
$dbhost = "localhost";
$dbname = "java";
$dbuser = "root";
$dbpass = "";
?>