<?php

$hot = $con->query("SELECT * FROM `file` WHERE `ivent` = 1 AND `downs` > 2 ORDER BY `downs` DESC LIMIT 10");
echo '<title>'.$title.'</title>';
echo '<div id="header"><a href="#back" onclick="history.back();" class="iconfont icon-fanhui"></a>';
echo '<h1>'.$title.'</h1>';
echo '<div id="user">';
if(!$user){
echo '<a href="/auth">登录</a></div></div>';
}else{
echo '<a href="/user">'.$user['name'].'</a>';
}
echo '</div></div>';
include_once $_SERVER["DOCUMENT_ROOT"] . '/style/menu.php';
echo '<div id="nav"><span>位置：</span><span>首页</span></div>';
echo '<div id="wrapper" class="clearfix"><div id="main">';
//echo '<div class="chk_red">
//<span class="title_chk_red">热门</span><div class="block">';
//while($w = $hot->fetch_assoc()){

//echo '<div class="link_game"><a href="/file/'.$w['id'].'"> <div class="example3">
//<img src="/icon/'.$w['id'].'" width="23" height="23" alt="图标" /> <div class="example_text">'.$w['name'].'<span><i class="fas fa-file-download ic"></i> 下载: '.$w['downs'].' 次.</span></div></div></a></div>';

//}
//$comment = $con->query("SELECT * FROM `comment` WHERE `id_obmen` ='{$file['id']}' ORDER BY `id` DESC LIMIT 5");
//while($comm = $comment->fetch_assoc()){
echo '<h2 class="topic bg-white">新评论</h2>
<ul class="list comment line padding bg-white" id="comment">
<li class="clearfix">
<a href="/info/'.$b['id_user'].'">
<img src="https://thirdqq.qlogo.cn/g?b=oidb&amp;k=rESO3zNIoazIfDGbWkl6jQ&amp;s=40&amp;t=1575744590" width="46" height="46" alt="头像" />
</a><div><p>
<a href="/info/'.$b['id_user'].'">'.$b['id_user'].'</a>：'.user($comm['id_user']).'</p>
<div class="small-font">
<a href="/comments/reply/3079" class="right">回复</a>'.text($comm['text']).'</div></div></li>';
//}
echo '</ul></div>';
//$ms = $con->query("SELECT * FROM `user` ORDER BY `id` DESC LIMIT $start, 10");
//while($w = $ms->fetch_assoc()){
echo '<div id="aside">
<h2 class="topic bg-white">
<a href="/login" class="right">我要加入</a>19346位小伙伴</h2>
<div class="faces">
<a href="/user/19346">
<img src="https://thirdqq.qlogo.cn/g?b=oidb&amp;k=7ibYVDYOwIIu8ib6KpOXTwhw&amp;s=40&amp;t=1614960903" width="24" height="24" alt="头像" /></a>';
//}
echo '</div>';
//while($comm = $comment->fetch_assoc()){
//echo '<h2 class="topic bg-white">新评论</h2><ul class="list comment line padding bg-white" id="comment">';
//echo '<li class="clearfix"><a href="/user/8220"><img src="https://himg.bdimg.com/sys/portraitn/item/5685706f73746261727573657273a259" width="46" height="46" alt="头像" /></a><div><p><a href="/user/8220">'.user($comm['id_user']).'</a>：'.text($comm['text']).'</p><div class="small-font"><a href="/comments/reply/2912" class="right">回复</a>1小时前</div></div></li>';
//echo '</ul></div>';
//}
$new = $con->query("SELECT * FROM `file` WHERE `ivent` = 1 ORDER BY `id` DESC LIMIT 10");
echo '<h2 class="topic margin-top bg-white"><a href="/games?order=id">新收录</a></h2><ul class="list icon small line bg-white"><li>';
while($w = $new->fetch_assoc()){
echo '<a href="file/'.$w['id'].'"><img src="/icon/'.$w['id'].'" width="23" height="23" alt="图标" />'.$w['name'].'</a>';
echo '</li><li>';
}
echo '</div></div>';
echo '<h2 class="topic margin-top bg-white"><a href="/games">TOP10</a></h2><ul class="list icon small line bg-white"><li>';

while($w = $hot->fetch_assoc()){
echo '<div class="link_game"><a href="file/'.$w['id'].'">
<img src="/icon/'.$w['id'].'" width="23" height="23" alt="图标" />'.$w['name'].'</a>';
echo '</li><li>';
}

//echo '
//<span class="title_chk_red">最新</span><div class="block">';
//while($w = $new->fetch_assoc()){

//echo '<div class="link_game"><a href="/file/'.$w['id'].'"> <div class="example3">
//<img class="img_rms" src="/icon/'.$w['id'].'"> <div class="example_text"><h6>'.$w['name'].'</h6><span><i class="fas fa-file-download ic"></i> 下载: '.$w['downs'].' 次.</span></div></div></a></div>';
//}
//echo'</div>';
//$up = $con->query("SELECT * FROM `file` WHERE `ivent` = 1 ORDER BY `id` DESC LIMIT 12");
//echo '
//<span class="title_chk_red">推荐</span><div class="block">';
//while($w = $up->fetch_assoc()){
//echo '<div class="link_game"><a href="/file/'.$w['id'].'"> <div class="example3">
//<img class="img_rms" src="/icon/'.$w['id'].'"> <div class="example_text"><h6>'.$w['name'].'</h6><span><i class="fas fa-file-download ic"></i> 下载: '.$w['downs'].' 次.</span></div></div></a></div>';
//}

echo '</div>';
?>