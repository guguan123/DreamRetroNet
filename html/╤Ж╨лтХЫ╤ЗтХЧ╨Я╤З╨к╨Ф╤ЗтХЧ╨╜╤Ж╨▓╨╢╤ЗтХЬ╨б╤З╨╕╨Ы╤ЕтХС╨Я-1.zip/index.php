<?php
echo '<body id="notice"><h2 class="topic">消息提示</h2><p>本站已关闭，请先前往 jvzh.cn</p>';
echo '</p><p><a href="http://jvzh.cn" class="button">前往</a></p>';