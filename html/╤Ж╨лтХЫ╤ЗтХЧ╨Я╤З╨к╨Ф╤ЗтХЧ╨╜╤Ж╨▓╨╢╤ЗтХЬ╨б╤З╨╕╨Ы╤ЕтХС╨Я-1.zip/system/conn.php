
<?php
$dbhost = "localhost";
$dbname = "wap";
$dbuser = "wap";
$dbpass = "123456";
?>