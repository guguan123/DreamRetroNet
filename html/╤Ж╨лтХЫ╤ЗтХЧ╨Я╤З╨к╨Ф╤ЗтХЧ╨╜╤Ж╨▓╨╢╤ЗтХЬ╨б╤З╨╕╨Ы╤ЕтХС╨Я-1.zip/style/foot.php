<?php

$end_time = microtime();

$end_array = explode(" ", $end_time);

$end_time = $end_array[1] + $end_array[0];

$time = $end_time - $start_time;
echo '<div id="footer" class="margin-top"><div><a href="/m/1">免责声明</a> | <a href="/m/2">联系我们</a> | <a href="/m/3">捐助网站</a> | <a href="/m/4">常见问题</a></div><div>&copy; 2016-2021 jvzh.cn <a href="https://beian.miit.gov.cn/">	滇ICP备2021002463号-2</a></div>';
//echo '</div>
//</div>
//</div>
//</div>
//<div class="bottom">
//    <div id="body">java游戏<a href="/">乐园</a> 2019</div>
//</div>';
?>

