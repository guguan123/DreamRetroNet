<?php
echo '<ul id="menu" class="bg-white"><li><a href="/">首页</a></li><li><a href="/class">分类</a></li><li><a href="/search">搜索</a></li><li><a href="/m/3">捐助</a></li></ul>';
?>
