<?php
/**
 * 发送请求(也可以直接使用guzzle)
 *
 * @param string $url      请求地址
 * @param array $data      请求数据
 * @param array $headers   请求头
 * @return string|array
 */
function sendRequest($url, $data = [], $headers = [])
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    if (!empty($data)) {
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    }
    $response = curl_exec($ch) ? curl_multi_getcontent($ch) : '';
    curl_close($ch);
    return $response;
}

// 组合请求参数
$code   = $_GET['code'];
$params = [
    'client_id'     => $app_id,
    'client_secret' => $app_secret,
    'code'          => $code,
];

// 发送请求并获取响应信息
$response = sendRequest($url, $params, ['Accept: application/json']);
$response = json_decode($response, true);

// 如果有响应信息， 说明请求成功
if (!empty($response['access_token'])) {
    // 请求成功，使用 access_token 获取用户信息
    $access_token = $response['access_token'];
    $url = "https://api.github.com/user";

    // 发送请求，调取github API 获取用户信息
    $userInfo =  sendRequest($url,[],[
        "Accept: application/json",
        "User-Agent: ilearn",  // 此处(ilearn)是填写应用名称 或者 github用户名
        "Authorization:token {$access_token}"
    ]);

    exit($userInfo);
}

// 如果登陆失败就打印错误信息
echo "<p>登陆失败</p></pre>";
var_dump($response);
exit("</pre>");
?>