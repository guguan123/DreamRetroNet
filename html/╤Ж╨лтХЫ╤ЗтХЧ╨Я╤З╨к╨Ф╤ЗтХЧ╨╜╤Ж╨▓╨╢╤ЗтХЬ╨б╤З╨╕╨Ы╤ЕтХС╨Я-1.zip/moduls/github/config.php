// 如果用户同意登陆， github 就会返回到 callback.php 并携带一个code参数
// 此时只需要使用这个 code 去获取 access_token, 然后在使用 access_token 获取用户信息
$url        = "https://github.com/login/oauth/access_token";
$app_id     = "c9cbb49f280cecfd3a7e";
$app_secret = "9d9cb1754ebec4ba5d74ae30dd93f8a567a5b8be";

