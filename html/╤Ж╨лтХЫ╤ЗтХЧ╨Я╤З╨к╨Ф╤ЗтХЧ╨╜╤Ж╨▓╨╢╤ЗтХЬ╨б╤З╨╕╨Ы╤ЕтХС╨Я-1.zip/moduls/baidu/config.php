<?php
/**
 * Created by PhpStorm.
 * User: tao
 * Date: 2016-09-13
 * Time: 23:14
 */
$api_key = 'xZjePzHv1AYxEKoxcGAMcT0s';
$serect_key = 'PbLhyTEsYvKz3yoCigejYh5LwbYaXr7l';
$redirect_url = 'https://jvzh.cn/moduls/callback.php';
$apibase_url = 'https://openapi.baidu.com/rest/2.0/';
$logout = 'http://www.baidu.com';


?>