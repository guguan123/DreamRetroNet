 <?php
/**
 * Created by PhpStorm.
 * User: tao
 * Date: 2016-09-13
 * Time: 23:14
 */
//应用的APPID 
   $app_id = "101951815"; 
   //应用的APPKEY 
   $app_secret = "f548d72f7cc9cf62fad30304cb8896c1"; 
   //【成功授权】后的回调地址，即此地址在腾讯的信息中有储存 
   $my_url = "你的回调网址"; 


?>