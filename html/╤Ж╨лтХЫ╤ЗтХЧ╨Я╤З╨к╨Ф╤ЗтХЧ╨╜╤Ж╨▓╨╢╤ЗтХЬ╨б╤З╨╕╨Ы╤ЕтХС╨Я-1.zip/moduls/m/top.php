<?php
echo '<div id="aside">
<ul class="list icon line bg-white">
<li><a href="/m/1">免责声明</a></li>
<li><a href="/m/2">联系我们</a></li>
<li><a href="/m/3">捐助网站</a></li>
<li><a href="/m/4">常见问题</a></li>
</ul></div></div>';
?>
